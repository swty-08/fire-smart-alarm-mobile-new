import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/reading.dart';
import '../repositories/reading_repository.dart';
import '../services/notification_service.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

const Color _background = Color(0xFFFFF9F8);
const Color _cardColor = Color(0xFFFFF0EE);
const Color _statusCardColor = Color(0xFFFFDDE2);
const Color _accent = Color(0xFF9E5148);

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final ReadingRepository _repository = ReadingRepository();
  int _mobileTab = 0;
  int _desktopTab = 0;
  int _desktopHistoryCount = 20;
  DateTimeRange? _reportDateRange;
  String _reportStatus = 'Semua';
  int _reportVisibleCount = 40;

  String? _lastNotifiedStatus;
  String? _lastNotifiedDevice;
  Future<void> _pickReportDateRange() async {
    final now = DateTime.now();
    final initialStart = _reportDateRange?.start ?? DateTime(now.year, now.month, now.day);
    DateTime visibleMonth = DateTime(initialStart.year, initialStart.month);
    DateTime? start = _reportDateRange?.start;
    DateTime? end = _reportDateRange?.end;

    final picked = await showDialog<DateTimeRange>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final firstDay = DateTime(visibleMonth.year, visibleMonth.month, 1);
          final daysInMonth = DateUtils.getDaysInMonth(visibleMonth.year, visibleMonth.month);
          // Sunday-first calendar, matching the familiar desktop calendar layout.
          final leading = firstDay.weekday % 7;
          final cells = ((leading + daysInMonth + 6) ~/ 7) * 7;
          String format(DateTime d) => '${d.day}/${d.month}/${d.year}';
          bool sameDay(DateTime? a, DateTime b) => a != null && a.year == b.year && a.month == b.month && a.day == b.day;
          bool inRange(DateTime d) => start != null && end != null && !d.isBefore(DateUtils.dateOnly(start!)) && !d.isAfter(DateUtils.dateOnly(end!));

          return Dialog(
            insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 350),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(children: [
                      const Expanded(child: Text('Pilih periode laporan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF352725)))),
                      IconButton(tooltip: 'Tutup', onPressed: () => Navigator.pop(dialogContext), icon: const Icon(Icons.close_rounded, size: 20)),
                    ]),
                    Row(children: [
                      IconButton(onPressed: () => setDialogState(() => visibleMonth = DateTime(visibleMonth.year, visibleMonth.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
                      Expanded(child: Center(child: Text('${_monthName(visibleMonth.month)} ${visibleMonth.year}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
                      IconButton(onPressed: () => setDialogState(() => visibleMonth = DateTime(visibleMonth.year, visibleMonth.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
                    ]),
                    const SizedBox(height: 4),
                    Row(children: ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((d) => Expanded(child: Center(child: Text(d, style: const TextStyle(fontSize: 10, color: Colors.black54, fontWeight: FontWeight.w600))))).toList()),
                    const SizedBox(height: 6),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: cells,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 3, crossAxisSpacing: 3),
                      itemBuilder: (context, index) {
                        final day = index - leading + 1;
                        if (day < 1 || day > daysInMonth) return const SizedBox.shrink();
                        final date = DateTime(visibleMonth.year, visibleMonth.month, day);
                        final selected = sameDay(start, date) || sameDay(end, date);
                        final range = inRange(date);
                        return InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () => setDialogState(() {
                            if (start == null || end != null || date.isBefore(start!)) {
                              start = date;
                              end = null;
                            } else {
                              end = date;
                            }
                          }),
                          child: Container(
                            decoration: BoxDecoration(color: selected ? _accent : range ? _cardColor : Colors.transparent, shape: BoxShape.circle),
                            alignment: Alignment.center,
                            child: Text('$day', style: TextStyle(fontSize: 12, color: selected ? Colors.white : const Color(0xFF352725), fontWeight: selected ? FontWeight.w700 : FontWeight.normal)),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    Align(alignment: Alignment.centerLeft, child: Text(start == null ? 'Pilih tanggal mulai' : end == null ? 'Mulai: ${format(start!)} · Pilih tanggal akhir' : '${format(start!)} – ${format(end!)}', style: const TextStyle(fontSize: 11, color: Colors.black54))),
                    const SizedBox(height: 12),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal', style: TextStyle(fontSize: 13))),
                      const SizedBox(width: 6),
                      FilledButton(onPressed: start != null && end != null ? () => Navigator.pop(dialogContext, DateTimeRange(start: DateUtils.dateOnly(start!), end: DateUtils.dateOnly(end!))) : null, style: FilledButton.styleFrom(backgroundColor: _accent, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)), child: const Text('Terapkan', style: TextStyle(fontSize: 13))),
                    ]),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
    if (picked != null && mounted) {
      setState(() {
        _reportDateRange = picked;
        _reportVisibleCount = 40;
      });
    }
  }

  String _monthName(int month) {
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return months[month - 1];
  }

  @override
  Widget build(BuildContext context) {
    final isWeb = MediaQuery.sizeOf(context).width >= 900;
    return Scaffold(
      backgroundColor: _background,
      appBar: isWeb
          ? null
          : AppBar(
              backgroundColor: _background,
              elevation: 0,
              centerTitle: true,
              title: Text(
                const ['Beranda', 'Riwayat', 'Laporan', 'Pengaturan'][_mobileTab],
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              actions: const [
                Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: Icon(Icons.notifications, color: Color(0xFFB33A35)),
                ),
              ],
            ),

      bottomNavigationBar: isWeb
          ? null
          : BottomNavigationBar(
              currentIndex: _mobileTab,
              selectedItemColor: _accent,
              unselectedItemColor: Colors.black54,
              backgroundColor: Colors.white,
              type: BottomNavigationBarType.fixed,
              onTap: (i) => setState(() => _mobileTab = i),
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Beranda'),
                BottomNavigationBarItem(icon: Icon(Icons.list_alt_rounded), label: 'Riwayat'),
                BottomNavigationBarItem(icon: Icon(Icons.assessment_rounded), label: 'Laporan'),
                BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'Pengaturan'),
              ],
            ),
      body: StreamBuilder<List<Reading>>(
        stream: _repository.getReadings(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting &&
              !snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(color: _accent),
            );
          }
          if (snapshot.hasError) {
            return _message(
              'Data tidak dapat dibaca',
              'Periksa koneksi internet dan pengaturan Firebase.\n${snapshot.error}',
            );
          }
          final readings = snapshot.data ?? [];
          if (readings.isEmpty) {
            if (!isWeb && _mobileTab == 2) {
              return SafeArea(child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
                child: _buildReportSection(readings),
              ));
            }
            if (!isWeb && _mobileTab == 3) {
              return const MobileSettingsScreen(embedded: true);
            }
            if (!isWeb && _mobileTab == 1) {
              return _message('Belum ada riwayat', 'Data sensor akan tampil setelah tersedia di Firebase.');
            }
            return _message(
              'Belum ada data sensor',
              'Data dari Firebase akan tampil di halaman ini.',
            );
          }
          final latest = readings.first;
          final currentStatus = latest.status.toLowerCase();

          if (currentStatus == 'warning' || currentStatus == 'danger') {
            if (_lastNotifiedStatus != latest.status ||
                _lastNotifiedDevice != latest.deviceId) {
              _lastNotifiedStatus = latest.status;
              _lastNotifiedDevice = latest.deviceId;

              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;

                NotificationService.showStatusNotification(
                  status: latest.status,
                  temperature: latest.temperature,
                  smoke: latest.smoke,
                );
              });
            }
          } else {
            _lastNotifiedStatus = null;
            _lastNotifiedDevice = null;
          }
          final trend = readings.take(20).toList().reversed.toList();
          if (!isWeb) {
            if (_mobileTab == 1) {
              final history = readings.take(_desktopHistoryCount).toList();
              return SafeArea(child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                children: [
                  _sectionTitle('Pilih jumlah data'),
                  const SizedBox(height: 10),
                  Row(children: [20, 50, 100].map((count) => Expanded(child: Padding(
                    padding: EdgeInsets.only(right: count == 100 ? 0 : 8),
                    child: ChoiceChip(
                      label: Center(child: Text('$count')),
                      selected: _desktopHistoryCount == count,
                      showCheckmark: false,
                      selectedColor: _accent,
                      backgroundColor: _cardColor,
                      labelStyle: TextStyle(color: _desktopHistoryCount == count ? Colors.white : Colors.black87, fontWeight: FontWeight.bold),
                      onSelected: (_) => setState(() => _desktopHistoryCount = count),
                    ),
                  ))).toList()),
                  const SizedBox(height: 14),
                  _buildChartCard(history.reversed.toList(), height: 190),
                  const SizedBox(height: 20),
                  _sectionTitle('Riwayat Sensor (${history.length} data)'),
                  const SizedBox(height: 10),
                  if (history.isEmpty) const Text('Belum ada riwayat sensor.')
                  else ...history.asMap().entries.map((e) => _buildHistoryCard(e.value, e.key + 1)),
                ],
              ));
            }
            if (_mobileTab == 2) {
              return SafeArea(child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
                child: _buildReportSection(readings),
              ));
            }
            if (_mobileTab == 3) return const MobileSettingsScreen(embedded: true);
            return SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 560),
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    children: [
                      _buildStatusCard(latest),
                      const SizedBox(height: 12),
                      const _AlarmControlCard(),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _buildSensorCard(
                              icon: Icons.thermostat,
                              title: 'Temperature',
                              value:
                                  '${latest.temperature.toStringAsFixed(1)} °C',
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _buildSensorCard(
                              icon: Icons.water_drop,
                              title: 'Humidity',
                              value: '${latest.humidity.toStringAsFixed(1)} %',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _buildMq2Card(latest),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _buildInfoCard(
                              icon: Icons.memory,
                              title: 'Device ID',
                              value: latest.deviceId,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _buildInfoCard(
                              icon: Icons.access_time,
                              title: 'Last Update',
                              value: _formatDateTime(latest.timestamp),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _sectionTitle('Tren 20 data terakhir'),
                      const SizedBox(height: 10),
                      _buildChartCard(trend, height: 180),
                      const SizedBox(height: 20),
                      _sectionTitle('Riwayat Sensor Terbaru'),
                      const SizedBox(height: 10),
                      ...readings
                          .take(5)
                          .toList()
                          .asMap()
                          .entries
                          .map((e) => _buildHistoryCard(e.value, e.key + 1)),
                      OutlinedButton.icon(
                        onPressed: () => setState(() => _mobileTab = 1),
                        icon: const Icon(Icons.history),
                        label: const Text('Lihat Semua Riwayat'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
          return Row(
            children: [
              Container(
                width: 205,
                color: const Color(0xFF9E342F),
                child: SafeArea(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.fromLTRB(20, 22, 12, 30),
                        child: Row(
                          children: [
                            Icon(
                              Icons.local_fire_department,
                              color: Colors.white,
                              size: 30,
                            ),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Fire Smart Alarm',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _sideItem(
                        Icons.dashboard,
                        'Dashboard',
                        _desktopTab == 0,
                        () => setState(() => _desktopTab = 0),
                      ),
                      _sideItem(
                        Icons.list_alt,
                        'Riwayat Sensor',
                        _desktopTab == 1,
                        () => setState(() => _desktopTab = 1),
                      ),
                      _sideItem(
                        Icons.show_chart,
                        'Grafik',
                        _desktopTab == 2,
                        () => setState(() => _desktopTab = 2),
                      ),
                      _sideItem(
                        Icons.settings,
                        'Pengaturan',
                        _desktopTab == 3,
                        () => setState(() => _desktopTab = 3),
                      ),
                      _sideItem(
                        Icons.info,
                        'Tentang',
                        _desktopTab == 4,
                        () => setState(() => _desktopTab = 4),
                      ),

                      _sideItem(
                        Icons.assessment,
                        'Laporan',
                        _desktopTab == 5,
                        () => setState(() => _desktopTab = 5),
                      ),

                      const SizedBox(height: 12),

                      _sideItem(Icons.logout, 'Logout', false, () async {
                        final shouldLogout = await showDialog<bool>(
                          context: context,
                          builder: (dialogContext) => AlertDialog(
                            title: const Text('Logout'),
                            content: const Text(
                              'Apakah kamu yakin ingin keluar dari akun?',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, false),
                                child: const Text('Batal'),
                              ),
                              FilledButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, true),
                                child: const Text('Logout'),
                              ),
                            ],
                          ),
                        );

                        if (shouldLogout == true) {
                          await FirebaseAuth.instance.signOut();
                        }
                      }),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: SafeArea(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(22, 18, 22, 26),
                    children: [
                      if (_desktopTab != 5) ...[
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _desktopTab == 1
                                        ? 'Riwayat Sensor'
                                        : _desktopTab == 2
                                        ? 'Grafik Sensor'
                                        : _desktopTab == 3
                                        ? 'Pengaturan Sistem'
                                        : _desktopTab == 4
                                        ? 'Tentang Fire Smart Alarm'
                                        : 'Dashboard Monitoring',
                                    style: const TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    _desktopTab == 1
                                        ? 'Lihat riwayat pembacaan sensor.'
                                        : _desktopTab == 2
                                        ? 'Pantau perubahan suhu, kelembapan, dan asap.'
                                        : _desktopTab == 3
                                        ? 'Kelola alarm dan lihat aturan kondisi sensor.'
                                        : 'Pantau kondisi laboratorium secara real-time',
                                    style: const TextStyle(
                                      color: Colors.black54,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(
                              Icons.circle,
                              color: Colors.red,
                              size: 10,
                            ),
                            const SizedBox(width: 7),
                            const Text(
                              'Real-time',
                              style: TextStyle(color: Colors.red, fontSize: 12),
                            ),
                            const SizedBox(width: 22),
                            Text(
                              _formatDateTime(DateTime.now()),
                              style: const TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                      ],
                      if (_desktopTab == 0) ...[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: SizedBox(
                                height: 174,
                                child: _buildStatusCard(latest),
                              ),
                            ),
                            const SizedBox(width: 14),
                            const Expanded(
                              child: SizedBox(
                                height: 174,
                                child: _AlarmControlCard(),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            const gap = 12.0;
                            final cardWidth =
                                (constraints.maxWidth - gap * 3) / 4;
                            const cardHeight = 144.0;
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: cardWidth,
                                  height: cardHeight,
                                  child: _buildSensorCard(
                                    icon: Icons.thermostat,
                                    title: 'Temperature',
                                    value:
                                        '${latest.temperature.toStringAsFixed(1)} °C',
                                  ),
                                ),
                                const SizedBox(width: gap),
                                SizedBox(
                                  width: cardWidth,
                                  height: cardHeight,
                                  child: _buildSensorCard(
                                    icon: Icons.water_drop,
                                    title: 'Humidity',
                                    value:
                                        '${latest.humidity.toStringAsFixed(1)} %',
                                  ),
                                ),
                                const SizedBox(width: gap),
                                SizedBox(
                                  width: cardWidth,
                                  height: cardHeight,
                                  child: _buildMq2Card(latest),
                                ),
                                const SizedBox(width: gap),
                                SizedBox(
                                  width: cardWidth,
                                  height: cardHeight,
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: _buildInfoCard(
                                          icon: Icons.memory,
                                          title: 'Device ID',
                                          value: latest.deviceId,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Expanded(
                                        child: _buildInfoCard(
                                          icon: Icons.access_time,
                                          title: 'Last Update',
                                          value: _formatDateTime(
                                            latest.timestamp,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                        const SizedBox(height: 16),
                        _sectionTitle('Grafik 20 data terakhir'),
                        const SizedBox(height: 10),
                        _buildChartCard(trend, height: 118),
                        const SizedBox(height: 18),
                        _sectionTitle('Riwayat Sensor Terbaru'),
                        const SizedBox(height: 8),
                        _desktopHistoryTable(readings.take(5).toList()),
                      ] else if (_desktopTab == 1) ...[
                        _sectionTitle('Pilih jumlah data'),
                        const SizedBox(height: 10),
                        Row(
                          children: [20, 50, 100]
                              .map(
                                (dataCount) => Expanded(
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      right: dataCount == 100 ? 0 : 10,
                                    ),
                                    child: ChoiceChip(
                                      label: Center(child: Text('$dataCount')),
                                      selected: _desktopHistoryCount == dataCount,
                                      showCheckmark: false,
                                      selectedColor: _accent,
                                      backgroundColor: _cardColor,
                                      labelStyle: TextStyle(
                                        color: _desktopHistoryCount == dataCount
                                            ? Colors.white
                                            : Colors.black87,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                        side: BorderSide.none,
                                      ),
                                      onSelected: (_) => setState(
                                        () => _desktopHistoryCount = dataCount,
                                      ),
                                    ),
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                        const SizedBox(height: 14),
                        _buildChartCard(
                          readings
                              .take(_desktopHistoryCount)
                              .toList()
                              .reversed
                              .toList(),
                          height: 220,
                        ),
                        const SizedBox(height: 18),
                        _sectionTitle(
                          'Daftar Riwayat Sensor (${readings.length > _desktopHistoryCount ? _desktopHistoryCount : readings.length} data terbaru)',
                        ),
                        const SizedBox(height: 8),
                        _desktopHistoryTable(
                          readings.take(_desktopHistoryCount).toList(),
                        ),
                      ] else if (_desktopTab == 2) ...[
                        Center(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 1100),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _sectionTitle('Tren 20 data sensor terakhir'),
                                const SizedBox(height: 10),
                                _buildChartCard(trend, height: 280),
                                const SizedBox(height: 16),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: _buildSensorCard(
                                        icon: Icons.thermostat,
                                        title: 'Suhu terbaru',
                                        value:
                                            '${latest.temperature.toStringAsFixed(1)} °C',
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: _buildSensorCard(
                                        icon: Icons.water_drop,
                                        title: 'Kelembapan terbaru',
                                        value:
                                            '${latest.humidity.toStringAsFixed(1)} %',
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(child: _buildMq2Card(latest)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ] else if (_desktopTab == 3) ...[
                        const _AlarmControlCard(),
                        const SizedBox(height: 16),
                        _sectionTitle('Aturan Status Sensor'),
                        const SizedBox(height: 8),
                        _settingsInfoCard(
                          Icons.check_circle,
                          'Normal',
                          'Asap di bawah 450 ppm',
                          Colors.green,
                        ),
                        _settingsInfoCard(
                          Icons.warning_amber_rounded,
                          'Warning',
                          'Asap mulai 450 hingga 599 ppm',
                          Colors.orange,
                        ),
                        _settingsInfoCard(
                          Icons.warning_rounded,
                          'Danger',
                          'Asap 600 ppm atau lebih',
                          Colors.red,
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'Catatan: pengaturan ambang sensor mengikuti logika yang tertanam pada ESP32. Tombol di atas hanya mengaktifkan atau mematikan bunyi alarm.',
                          style: TextStyle(fontSize: 12, color: Colors.black54),
                        ),
                      ] else if (_desktopTab == 4) ...[
                        Center(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 1100),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: const Color(0xFFEDE1DF),
                                ),
                              ),
                              child: const Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    Icons.local_fire_department,
                                    color: Color(0xFFF44336),
                                    size: 34,
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Fire Smart Alarm',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    'Sistem pemantauan kondisi laboratorium menggunakan sensor suhu, kelembapan, dan asap. Data ditampilkan secara real-time untuk membantu pengguna memantau kondisi ruangan.',
                                    style: TextStyle(fontSize: 13),
                                  ),
                                  SizedBox(height: 10),
                                  Text(
                                    'Komponen: ESP32, DHT22, MQ-2, buzzer, LED, dan Firebase Firestore.',
                                    style: TextStyle(fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ] else if (_desktopTab == 5) ...[
                        _buildReportSection(readings),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildReportSection(List<Reading> readings) {
    final filtered = readings.where((reading) {
      final statusMatches =
          _reportStatus == 'Semua' ||
          reading.status.toLowerCase() == _reportStatus.toLowerCase();
      final range = _reportDateRange;
      final dateMatches =
          range == null ||
          (!reading.timestamp.isBefore(
                DateTime(range.start.year, range.start.month, range.start.day),
              ) &&
              reading.timestamp.isBefore(
                DateTime(range.end.year, range.end.month, range.end.day + 1),
              ));
      return statusMatches && dateMatches;
    }).toList();

    final dangerCount = filtered
        .where((r) => r.status.toLowerCase() == 'danger')
        .length;
    final warningCount = filtered
        .where((r) => r.status.toLowerCase() == 'warning')
        .length;
    final normalCount = filtered
        .where((r) => r.status.toLowerCase() == 'normal')
        .length;
    final averageTemp = filtered.isEmpty
        ? 0.0
        : filtered.map((r) => r.temperature).reduce((a, b) => a + b) /
              filtered.length;
    final averageHumidity = filtered.isEmpty
        ? 0.0
        : filtered.map((r) => r.humidity).reduce((a, b) => a + b) /
              filtered.length;
    final averageSmoke = filtered.isEmpty
        ? 0.0
        : filtered.map((r) => r.smoke).reduce((a, b) => a + b) /
              filtered.length;
    final chartReadings = filtered.reversed.toList();
    // Batasi titik grafik agar CustomPainter tidak menggambar ribuan titik.
    const maxChartPoints = 180;
    final chartStep = chartReadings.length > maxChartPoints
        ? (chartReadings.length / maxChartPoints).ceil()
        : 1;
    final chartPoints = chartStep == 1
        ? chartReadings
        : [
            for (var i = 0; i < chartReadings.length; i += chartStep)
              chartReadings[i],
          ];
    final visibleMobileCount = _reportVisibleCount.clamp(0, filtered.length);
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isMobile = screenWidth < 600;
    final isNarrow = screenWidth < 1100;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1400),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Laporan Monitoring Sensor',
                    style: TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            const Text(
              'Ringkasan dan riwayat pembacaan sensor berdasarkan periode dan status.',
              style: TextStyle(color: Colors.black54, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFF0E2DF)),
                boxShadow: const [
                  BoxShadow(color: Color(0x0D6D332D), blurRadius: 18, offset: Offset(0, 5)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(color: _cardColor, borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.tune_rounded, color: _accent, size: 20),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Filter laporan', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF352725))),
                      SizedBox(height: 2),
                      Text('Sesuaikan periode dan status sensor', style: TextStyle(fontSize: 11, color: Colors.black54)),
                    ])),
                    if (!isMobile)
                      FilledButton.icon(
                        onPressed: filtered.isEmpty ? null : () => _exportReportPdf(filtered),
                        icon: const Icon(Icons.picture_as_pdf_rounded, size: 18),
                        label: const Text('Ekspor PDF'),
                        style: FilledButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13), textStyle: const TextStyle(fontSize: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      ),
                  ]),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 12,
                    runSpacing: 10,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                  OutlinedButton.icon(
                    onPressed: _pickReportDateRange,
                    style: OutlinedButton.styleFrom(foregroundColor: _accent, side: const BorderSide(color: Color(0xFFE3C9C4)), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    icon: const Icon(Icons.calendar_month_rounded, size: 19),
                    label: Text(
                      _reportDateRange == null
                          ? 'Semua tanggal'
                          : '${_dateOnly(_reportDateRange!.start)} – ${_dateOnly(_reportDateRange!.end)}',
                    ),
                  ),
                  if (isMobile)
                    FilledButton.icon(
                      onPressed: filtered.isEmpty ? null : () => _exportReportPdf(filtered),
                      icon: const Icon(Icons.picture_as_pdf_rounded, size: 18),
                      label: const Text('Ekspor PDF'),
                      style: FilledButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15), textStyle: const TextStyle(fontSize: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    ),
                  SizedBox(
                    width: 200,
                    height: 50,
                    child: DropdownButtonFormField<String>(
                      initialValue: _reportStatus,
                      isExpanded: true,
                      style: const TextStyle(fontSize: 14, color: Color(0xFF352725)),
                      decoration: InputDecoration(
                        isDense: true,
                        labelText: 'Status sensor',
                        labelStyle: const TextStyle(fontSize: 12, color: _accent),
                        prefixIcon: const Icon(Icons.sensors_rounded, color: _accent, size: 18),
                        filled: true,
                        fillColor: const Color(0xFFFFFBFA),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE3C9C4))),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE3C9C4))),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'Semua',
                          child: Text('Semua status'),
                        ),
                        DropdownMenuItem(
                          value: 'Normal',
                          child: Text('Normal'),
                        ),
                        DropdownMenuItem(
                          value: 'Warning',
                          child: Text('Warning'),
                        ),
                        DropdownMenuItem(
                          value: 'Danger',
                          child: Text('Danger'),
                        ),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setState(() {
                            _reportStatus = value;
                            _reportVisibleCount = 40;
                          });
                        }
                      },
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => setState(() {
                      _reportDateRange = null;
                      _reportStatus = 'Semua';
                      _reportVisibleCount = 40;
                    }),
                    style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF675A57), side: const BorderSide(color: Color(0xFFE8DEDC)), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13), textStyle: const TextStyle(fontSize: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    icon: const Icon(Icons.restart_alt_rounded, size: 19),
                    label: const Text('Reset'),
                  ),
                ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            LayoutBuilder(
              builder: (context, constraints) {
                final columns = constraints.maxWidth >= 1000
                    ? 4
                    : constraints.maxWidth >= 600
                    ? 2
                    : 1;
                const gap = 12.0;
                final width =
                    (constraints.maxWidth - gap * (columns - 1)) / columns;
                return Wrap(
                  spacing: gap,
                  runSpacing: gap,
                  children: [
                    SizedBox(
                      width: width,
                      child: _reportSummaryCard(
                        'Total Data',
                        '${filtered.length}',
                        Icons.sensors,
                        _accent,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: _reportSummaryCard(
                        'Normal',
                        '$normalCount',
                        Icons.check_circle,
                        Colors.green,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: _reportSummaryCard(
                        'Warning',
                        '$warningCount',
                        Icons.warning_amber,
                        Colors.orange,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: _reportSummaryCard(
                        'Danger',
                        '$dangerCount',
                        Icons.warning,
                        Colors.red,
                      ),
                    ),
                  ],
                );
              },
            ),
            const SizedBox(height: 12),
            LayoutBuilder(
              builder: (context, constraints) {
                final columns = constraints.maxWidth >= 900 ? 3 : 1;
                const gap = 12.0;
                final width =
                    (constraints.maxWidth - gap * (columns - 1)) / columns;
                return Wrap(
                  spacing: gap,
                  runSpacing: gap,
                  children: [
                    SizedBox(
                      width: width,
                      child: _reportMetricCard(
                        'Rata-rata Suhu',
                        '${averageTemp.toStringAsFixed(1)} °C',
                        Icons.thermostat,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: _reportMetricCard(
                        'Rata-rata Kelembapan',
                        '${averageHumidity.toStringAsFixed(1)} %',
                        Icons.water_drop,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: _reportMetricCard(
                        'Rata-rata Asap',
                        '${averageSmoke.toStringAsFixed(1)} ppm',
                        Icons.air,
                      ),
                    ),
                  ],
                );
              },
            ),
            const SizedBox(height: 20),
            const Text(
              'Grafik Sensor',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (filtered.length < 2)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text(
                  'Minimal dua data diperlukan untuk menampilkan grafik.',
                  textAlign: TextAlign.center,
                ),
              )
            else
              LayoutBuilder(
                builder: (context, constraints) {
                  final columns = constraints.maxWidth >= 1000
                      ? 3
                      : isNarrow
                      ? 1
                      : 2;
                  const gap = 12.0;
                  final width =
                      (constraints.maxWidth - gap * (columns - 1)) / columns;
                  return Wrap(
                    spacing: gap,
                    runSpacing: gap,
                    children: [
                      SizedBox(
                        width: width,
                        child: _reportChartCard(
                          'Suhu (°C)',
                          chartPoints.map((r) => r.temperature).toList(),
                          _accent,
                        ),
                      ),
                      SizedBox(
                        width: width,
                        child: _reportChartCard(
                          'Kelembapan (%)',
                          chartPoints.map((r) => r.humidity).toList(),
                          Colors.blue,
                        ),
                      ),
                      SizedBox(
                        width: width,
                        child: _reportChartCard(
                          'Asap (ppm)',
                          chartPoints.map((r) => r.smoke).toList(),
                          Colors.deepOrange,
                        ),
                      ),
                    ],
                  );
                },
              ),
            const SizedBox(height: 20),
            Text(
              'Detail Data (${filtered.length} data)',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (filtered.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text(
                  'Tidak ada data untuk filter yang dipilih.',
                  textAlign: TextAlign.center,
                ),
              )
            else if (MediaQuery.sizeOf(context).width < 600)
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Tampilkan bertahap supaya ribuan kartu tidak dibuat sekaligus.
                  for (var i = 0; i < visibleMobileCount; i++)
                    _mobileReportDataCard(filtered[i], i + 1),
                  if (visibleMobileCount < filtered.length) ...[
                    const SizedBox(height: 4),
                    Center(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() {
                          _reportVisibleCount =
                              (_reportVisibleCount + 40).clamp(0, filtered.length);
                        }),
                        icon: const Icon(Icons.expand_more_rounded),
                        label: Text(
                          'Tampilkan 40 data lagi (${filtered.length - visibleMobileCount} tersisa)',
                        ),
                      ),
                    ),
                  ],
                ],
              )
            else ...[
              _desktopHistoryTable(filtered.take(visibleMobileCount).toList()),
              if (visibleMobileCount < filtered.length) ...[
                const SizedBox(height: 8),
                Center(
                  child: OutlinedButton.icon(
                    onPressed: () => setState(() {
                      _reportVisibleCount =
                          (_reportVisibleCount + 40).clamp(0, filtered.length);
                    }),
                    icon: const Icon(Icons.expand_more_rounded),
                    label: Text(
                      'Tampilkan 40 data lagi (${filtered.length - visibleMobileCount} tersisa)',
                    ),
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _mobileReportDataCard(Reading reading, int number) {
    final status = reading.status.toUpperCase();
    final color = _statusColor(status);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE8DEDC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Data #$number',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusLabel(status),
                  style: TextStyle(color: color, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _formatDateTime(reading.timestamp),
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
          const Divider(height: 18),
          _reportDataRow('Suhu', '${reading.temperature.toStringAsFixed(1)} °C', Icons.thermostat),
          const SizedBox(height: 8),
          _reportDataRow('Kelembapan', '${reading.humidity.toStringAsFixed(1)} %', Icons.water_drop),
          const SizedBox(height: 8),
          _reportDataRow('Asap', '${reading.smoke.toStringAsFixed(0)} ppm', Icons.air),
        ],
      ),
    );
  }

  Widget _reportDataRow(String label, String value, IconData icon) => Row(
    children: [
      Icon(icon, size: 17, color: _accent),
      const SizedBox(width: 8),
      Expanded(child: Text(label, style: const TextStyle(fontSize: 13))),
      Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
    ],
  );

  Widget _reportSummaryCard(
    String title,
    String count,
    IconData icon,
    Color color,
  ) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: const Color(0xFFEDE1DF)),
    ),
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 4),
              Text(
                count,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _reportMetricCard(String title, String value, IconData icon) =>
      Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFEDE1DF)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _cardColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: _accent),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _reportChartCard(String title, List<double> values, Color color) =>
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFEDE1DF)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 160,
              width: double.infinity,
              child: CustomPaint(painter: _ReportLinePainter(values, color)),
            ),
            const SizedBox(height: 6),
            const Text(
              'Urutan waktu: data lama ke terbaru',
              style: TextStyle(fontSize: 10, color: Colors.black54),
            ),
          ],
        ),
      );

  Future<void> _exportReportPdf(List<Reading> readings) async {
    final pdf = pw.Document();
    final normal = readings
        .where((r) => r.status.toLowerCase() == 'normal')
        .length;
    final warning = readings
        .where((r) => r.status.toLowerCase() == 'warning')
        .length;
    final danger = readings
        .where((r) => r.status.toLowerCase() == 'danger')
        .length;
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Text(
            'Laporan Monitoring Sensor Fire Smart Alarm',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 6),
          pw.Text('Tanggal ekspor: ${_formatDateTime(DateTime.now())}'),
          pw.Text(
            'Periode: ${_reportDateRange == null ? 'Semua tanggal' : '${_dateOnly(_reportDateRange!.start)} - ${_dateOnly(_reportDateRange!.end)}'}',
          ),
          pw.Text('Filter status: $_reportStatus'),
          pw.SizedBox(height: 12),
          pw.Text(
            'Ringkasan: ${readings.length} data | Normal: $normal | Warning: $warning | Danger: $danger',
          ),
          pw.SizedBox(height: 14),
          pw.TableHelper.fromTextArray(
            headers: [
              'Waktu',
              'Suhu (°C)',
              'Kelembapan (%)',
              'Asap (ppm)',
              'Status',
            ],
            data: readings
                .map(
                  (r) => [
                    _formatDateTime(r.timestamp),
                    r.temperature.toStringAsFixed(1),
                    r.humidity.toStringAsFixed(1),
                    r.smoke.toStringAsFixed(1),
                    _statusLabel(r.status.toUpperCase()),
                  ],
                )
                .toList(),
            headerStyle: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              fontSize: 9,
            ),
            cellStyle: const pw.TextStyle(fontSize: 8),
            cellAlignment: pw.Alignment.centerLeft,
          ),
        ],
      ),
    );
    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
      name: 'laporan_fire_smart_alarm.pdf',
    );
  }
}

String _dateOnly(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

class _ReportLinePainter extends CustomPainter {
  _ReportLinePainter(this.values, this.lineColor);
  final List<double> values;
  final Color lineColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2 || size.isEmpty) return;
    const pad = 10.0;
    final minValue = values.reduce((a, b) => a < b ? a : b);
    final maxValue = values.reduce((a, b) => a > b ? a : b);
    final range = (maxValue - minValue).abs() < 0.0001
        ? 1.0
        : maxValue - minValue;
    final chartHeight = size.height - pad * 2;
    final gridPaint = Paint()
      ..color = const Color(0xFFE8DEDC)
      ..strokeWidth = 1;
    for (var i = 0; i < 4; i++) {
      final y = pad + chartHeight * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = pad + chartHeight * (1 - (values[i] - minValue) / range);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = lineColor
        ..strokeWidth = 2.2
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant _ReportLinePainter oldDelegate) =>
      oldDelegate.lineColor != lineColor ||
      oldDelegate.values.length != values.length ||
      oldDelegate.values.asMap().entries.any(
        (entry) => entry.value != values[entry.key],
      );
}

class MobileSettingsScreen extends StatelessWidget {
  const MobileSettingsScreen({super.key, this.embedded = false});
  final bool embedded;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      appBar: embedded ? null : AppBar(
        backgroundColor: _background,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: !embedded,
        leading: embedded ? null : IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Pengaturan',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'Pengaturan Alarm',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Kelola alarm dan lihat aturan kondisi sensor laboratorium.',
              style: TextStyle(fontSize: 13, color: Colors.black54),
            ),
            const SizedBox(height: 16),
            const _AlarmControlCard(),
            const SizedBox(height: 22),
            const Text(
              'Aturan Status Sensor',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            _settingsInfoCard(
              Icons.check_circle,
              'Normal',
              'Asap di bawah 450 ppm',
              Colors.green,
            ),
            _settingsInfoCard(
              Icons.warning_amber_rounded,
              'Warning',
              'Asap mulai 450 hingga 599 ppm',
              Colors.orange,
            ),
            _settingsInfoCard(
              Icons.warning_rounded,
              'Danger',
              'Asap 600 ppm atau lebih',
              Colors.red,
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _cardColor,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, color: _accent),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Ambang sensor mengikuti logika yang tertanam pada ESP32. Tombol kontrol hanya mengatur aktif atau nonaktifnya alarm.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Color(0xFFEDE1DF))),
              tileColor: Colors.white,
              leading: const Icon(Icons.logout_rounded, color: Colors.red),
              title: const Text('Logout', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.red)),
              subtitle: const Text('Keluar dari akun Fire Smart Alarm'),
              onTap: () async {
                final shouldLogout = await showDialog<bool>(
                  context: context,
                  builder: (dialogContext) => AlertDialog(
                    title: const Text('Logout'),
                    content: const Text('Apakah kamu yakin ingin keluar dari akun?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
                      FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Logout')),
                    ],
                  ),
                );
                if (shouldLogout == true) await FirebaseAuth.instance.signOut();
              },
            ),
          ],
        ),
      ),
    );
  }
}

Widget _settingsInfoCard(
  IconData icon,
  String title,
  String description,
  Color color,
) => Container(
  width: double.infinity,
  margin: const EdgeInsets.only(bottom: 10),
  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(14),
    border: Border.all(color: const Color(0xFFEDE1DF)),
  ),
  child: Row(
    children: [
      Icon(icon, color: color, size: 24),
      const SizedBox(width: 10),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              description,
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
      ),
    ],
  ),
);
Widget _sideItem(
  IconData icon,
  String label,
  bool selected,
  VoidCallback onTap,
) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
  child: Material(
    color: selected ? Colors.white.withValues(alpha: 0.20) : Colors.transparent,
    borderRadius: BorderRadius.circular(10),
    child: ListTile(
      dense: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      selected: selected,
      selectedTileColor: Colors.transparent,
      leading: Icon(icon, color: Colors.white),
      title: Text(label, style: const TextStyle(color: Colors.white)),
      onTap: onTap,
    ),
  ),
);
Widget _desktopHistoryTable(List<Reading> readings) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: const Color(0xFFE8DEDC)),
    ),
    child: LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: constraints.maxWidth),
          child: DataTable(
            columnSpacing: 18,
            headingRowColor: WidgetStateProperty.all(Colors.white),
            headingTextStyle: const TextStyle(
              fontSize: 11,
              color: Colors.black87,
            ),
            dataTextStyle: const TextStyle(fontSize: 11, color: Colors.black87),
            dataRowMinHeight: 36,
            dataRowMaxHeight: 40,
            headingRowHeight: 38,
            columns: const [
              DataColumn(label: Text('Waktu')),
              DataColumn(label: Text('Suhu (°C)')),
              DataColumn(label: Text('Kelembapan (%)')),
              DataColumn(label: Text('Asap (ppm)')),
              DataColumn(label: Text('Status')),
            ],
            rows: readings.map((r) {
              final status = r.status.toUpperCase();
              final color = _statusColor(status);
              return DataRow(
                cells: [
                  DataCell(Text(_formatDateTime(r.timestamp))),
                  DataCell(Text(r.temperature.toStringAsFixed(1))),
                  DataCell(Text(r.humidity.toStringAsFixed(1))),
                  DataCell(Text(r.smoke.toStringAsFixed(0))),
                  DataCell(
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text(
                        _statusLabel(status),
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      ),
    ),
  );
}

class _AlarmControlCard extends StatelessWidget {
  const _AlarmControlCard();
  @override
  Widget build(BuildContext context) {
    final ref = FirebaseFirestore.instance
        .collection('alarm-control')
        .doc('esp32-lab');
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: ref.snapshots(),
      builder: (context, snapshot) {
        final enabled = snapshot.data?.data()?['alarmEnabled'] as bool? ?? true;
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFEDE1DF)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Kontrol Alarm',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 9),
              LayoutBuilder(
                builder: (context, constraints) {
                  final compact = constraints.maxWidth < 520;
                  final alarmInfo = Row(
                    children: [
                      Icon(
                        enabled
                            ? Icons.notifications_active
                            : Icons.notifications_off,
                        color: enabled ? _accent : Colors.red,
                        size: 30,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              enabled ? 'Alarm aktif' : 'Alarm dimatikan',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              enabled
                                  ? 'Buzzer dan LED dapat menyala saat kondisi danger.'
                                  : 'Buzzer dan LED tidak berbunyi saat alarm dimatikan.',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                  final alarmButton = ElevatedButton.icon(
                    onPressed:
                        snapshot.connectionState == ConnectionState.waiting
                        ? null
                        : () async {
                            try {
                              await ref.set({
                                'alarmEnabled': !enabled,
                                'acknowledged': !enabled,
                              }, SetOptions(merge: true));
                            } catch (e) {
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Gagal mengubah alarm: $e'),
                                  ),
                                );
                              }
                            }
                          },
                    icon: Icon(
                      enabled
                          ? Icons.notifications_off
                          : Icons.notifications_active,
                      size: 18,
                    ),
                    label: Text(enabled ? 'Matikan Alarm' : 'Aktifkan Alarm'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 9,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  );
                  if (compact) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        alarmInfo,
                        const SizedBox(height: 14),
                        alarmButton,
                      ],
                    );
                  }
                  return Row(
                    children: [
                      Expanded(child: alarmInfo),
                      const SizedBox(width: 16),
                      Container(
                        width: 1,
                        height: 62,
                        color: const Color(0xFFEDE1DF),
                      ),
                      const SizedBox(width: 16),
                      alarmButton,
                    ],
                  );
                },
              ),
              const SizedBox(height: 6),
              const Text(
                'Mematikan alarm tidak berarti kondisi laboratorium aman.',
                style: TextStyle(fontSize: 9, color: Colors.red),
              ),
            ],
          ),
        );
      },
    );
  }
}

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, required this.repository});
  final ReadingRepository repository;
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  int _selectedCount = 20;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Riwayat Suhu',
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
      body: StreamBuilder<List<Reading>>(
        stream: widget.repository.getReadings(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting &&
              !snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(color: _accent),
            );
          }
          if (snapshot.hasError) {
            return _message(
              'Riwayat tidak dapat dibaca',
              'Periksa koneksi internet dan pengaturan Firebase.\n${snapshot.error}',
            );
          }
          final allReadings = snapshot.data ?? [];
          if (allReadings.isEmpty) {
            return _message(
              'Belum ada riwayat',
              'Data sensor akan tampil setelah tersedia di Firebase.',
            );
          }
          final readings = allReadings.take(_selectedCount).toList();
          final chartReadings = readings.reversed.toList();
          return SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.sizeOf(context).width >= 900
                      ? 1400
                      : 560,
                ),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
                  children: [
                    _sectionTitle('Pilih jumlah data'),
                    const SizedBox(height: 12),
                    Row(
                      children: [20, 50, 100].map((dataCount) {
                        final selected = _selectedCount == dataCount;
                        return Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(
                              right: dataCount == 100 ? 0 : 10,
                            ),
                            child: ChoiceChip(
                              label: Center(child: Text('$dataCount')),
                              selected: selected,
                              showCheckmark: false,
                              selectedColor: _accent,
                              backgroundColor: _cardColor,
                              labelStyle: TextStyle(
                                color: selected ? Colors.white : Colors.black87,
                                fontWeight: FontWeight.bold,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side: BorderSide.none,
                              ),
                              onSelected: (_) {
                                setState(() => _selectedCount = dataCount);
                              },
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 18),
                    _buildChartCard(chartReadings, height: 220),
                    const SizedBox(height: 24),
                    _sectionTitle('Daftar riwayat (${readings.length} data)'),
                    const SizedBox(height: 12),
                    if (MediaQuery.sizeOf(context).width >= 900)
                      _desktopHistoryTable(readings)
                    else
                      ...readings.asMap().entries.map(
                        (entry) =>
                            _buildHistoryCard(entry.value, entry.key + 1),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

Widget _sectionTitle(String title) {
  return Text(
    title,
    style: const TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.bold,
      color: Colors.black87,
    ),
  );
}

Widget _message(String title, String subtitle) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.sensors, size: 48, color: _accent),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(subtitle, textAlign: TextAlign.center),
        ],
      ),
    ),
  );
}

Widget _buildStatusCard(Reading reading) {
  final status = reading.status.toUpperCase();
  final statusColor = _statusColor(status);
  final statusIcon = status == 'DANGER'
      ? Icons.warning_rounded
      : status == 'WARNING'
      ? Icons.warning_amber_rounded
      : Icons.check_circle;
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
    decoration: BoxDecoration(
      color: _statusCardColor,
      borderRadius: BorderRadius.circular(18),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.10),
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      children: [
        const Icon(
          Icons.local_fire_department,
          size: 36,
          color: Color(0xFFF44336),
        ),
        const SizedBox(height: 4),
        const Text(
          'STATUS SISTEM',
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 4),
        Icon(statusIcon, size: 25, color: statusColor),
        const SizedBox(height: 2),
        Text(
          _statusLabel(status),
          style: TextStyle(
            fontSize: 21,
            fontWeight: FontWeight.bold,
            color: statusColor,
          ),
        ),
      ],
    ),
  );
}

Widget _buildSensorCard({
  required IconData icon,
  required String title,
  required String value,
}) {
  return Container(
    constraints: const BoxConstraints(minHeight: 92),
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
    decoration: BoxDecoration(
      color: _cardColor,
      borderRadius: BorderRadius.circular(17),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.10),
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 27, color: _accent),
        const SizedBox(height: 5),
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 3),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildMq2Card(Reading reading) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
    decoration: BoxDecoration(
      color: _cardColor,
      borderRadius: BorderRadius.circular(17),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.10),
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Icon(Icons.air, size: 27, color: _accent),
        const SizedBox(height: 5),
        const Text(
          'MQ-2 Smoke',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          reading.smoke.toStringAsFixed(0),
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ],
    ),
  );
}

Widget _buildInfoCard({
  required IconData icon,
  required String title,
  required String value,
}) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    decoration: BoxDecoration(
      color: _cardColor,
      borderRadius: BorderRadius.circular(15),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.08),
          blurRadius: 4,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Row(
      children: [
        Icon(icon, size: 17, color: Colors.black54),
        const SizedBox(width: 7),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(fontSize: 9, color: Colors.black45),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget _buildChartCard(List<Reading> readings, {required double height}) {
  final labels = readings.isEmpty
      ? <String>[]
      : <String>[
          _formatTime(readings.first.timestamp),
          if (readings.length > 2)
            _formatTime(readings[readings.length ~/ 2].timestamp),
          if (readings.length > 1) _formatTime(readings.last.timestamp),
        ];
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
    decoration: BoxDecoration(
      color: _cardColor,
      borderRadius: BorderRadius.circular(17),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Suhu (°C)',
          style: TextStyle(
            fontSize: 11,
            color: Colors.black54,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: height,
          width: double.infinity,
          child: readings.length < 2
              ? const Center(
                  child: Text(
                    'Grafik memerlukan minimal 2 data.',
                    style: TextStyle(color: Colors.black54, fontSize: 12),
                  ),
                )
              : CustomPaint(
                  painter: _TemperatureChartPainter(
                    readings.map((r) => r.temperature).toList(),
                  ),
                ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: labels
              .map(
                (label) => Text(
                  label,
                  style: const TextStyle(fontSize: 10, color: Colors.black54),
                ),
              )
              .toList(),
        ),
      ],
    ),
  );
}

class _TemperatureChartPainter extends CustomPainter {
  _TemperatureChartPainter(this.values);
  final List<double> values;
  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2 || size.isEmpty) return;
    final minValue = values.reduce((a, b) => a < b ? a : b);
    final maxValue = values.reduce((a, b) => a > b ? a : b);
    final range = (maxValue - minValue).abs() < 0.1 ? 1.0 : maxValue - minValue;
    const padding = 12.0;
    final chartHeight = size.height - padding * 2;
    final gridPaint = Paint()
      ..color = const Color(0xFFD8C9C6)
      ..strokeWidth = 1;
    for (var i = 0; i < 4; i++) {
      final y = padding + chartHeight * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = padding + chartHeight * (1 - (values[i] - minValue) / range);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    final linePaint = Paint()
      ..color = _accent
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, linePaint);
  }

  @override
  bool shouldRepaint(covariant _TemperatureChartPainter oldDelegate) {
    if (oldDelegate.values.length != values.length) return true;
    for (var i = 0; i < values.length; i++) {
      if (oldDelegate.values[i] != values[i]) return true;
    }
    return false;
  }
}

Widget _buildHistoryCard(Reading reading, int number) {
  final status = reading.status.toUpperCase();
  final statusColor = _statusColor(status);
  return Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
    decoration: BoxDecoration(
      color: _cardColor,
      borderRadius: BorderRadius.circular(15),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.10),
          blurRadius: 4,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Data #$number',
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                _statusLabel(status),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Divider(height: 1, color: Color(0xFFD8C9C6)),
        const SizedBox(height: 12),
        _historyRow(
          icon: Icons.thermostat,
          title: 'Temperature:',
          value: '${reading.temperature.toStringAsFixed(1)} °C',
        ),
        const SizedBox(height: 10),
        _historyRow(
          icon: Icons.water_drop,
          title: 'Humidity:',
          value: '${reading.humidity.toStringAsFixed(1)} %',
        ),
        const SizedBox(height: 10),
        _historyRow(
          icon: Icons.air,
          title: 'MQ-2:',
          value: reading.smoke.toStringAsFixed(0),
        ),
        const SizedBox(height: 10),
        _historyRow(
          icon: Icons.access_time,
          title: 'Waktu:',
          value: _formatDateTime(reading.timestamp),
        ),
      ],
    ),
  );
}

Widget _historyRow({
  required IconData icon,
  required String title,
  required String value,
}) {
  return Row(
    children: [
      Icon(icon, size: 17, color: Colors.black87),
      const SizedBox(width: 10),
      SizedBox(
        width: 105,
        child: Text(
          title,
          style: const TextStyle(fontSize: 13, color: Colors.black87),
        ),
      ),
      const SizedBox(width: 8),
      Expanded(
        child: Text(
          value,
          textAlign: TextAlign.right,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
    ],
  );
}

Color _statusColor(String status) {
  if (status == 'DANGER' || status == 'DANGER') return Colors.red;
  if (status == 'WARNING' || status == 'WARNING') return Colors.orange;
  return const Color(0xFF4CAF50);
}

String _statusLabel(String status) {
  if (status == 'DANGER' || status == 'DANGER') return 'Danger';
  if (status == 'WARNING' || status == 'WARNING') return 'Warning';
  return 'Normal';
}

String _formatDateTime(DateTime dateTime) {
  return '${dateTime.day.toString().padLeft(2, '0')}/'
      '${dateTime.month.toString().padLeft(2, '0')}/'
      '${dateTime.year} '
      '${dateTime.hour.toString().padLeft(2, '0')}:'
      '${dateTime.minute.toString().padLeft(2, '0')}:'
      '${dateTime.second.toString().padLeft(2, '0')}';
}

String _formatTime(DateTime dateTime) {
  return '${dateTime.hour.toString().padLeft(2, '0')}.'
      '${dateTime.minute.toString().padLeft(2, '0')}';
}